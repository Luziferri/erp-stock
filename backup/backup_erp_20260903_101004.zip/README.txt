Backup ERP Stock - TeamBike / SportMed
Gerado em: 2026-09-03 10:10:04
Conteudo:
- backup_completo.xlsx (5 sheets: Produtos, Importacoes, Import_Produtos, Monitorizados, Definicoes)
- backup.json (dump completo em JSON)
- produtos.csv
- erp.db (base SQLite)
